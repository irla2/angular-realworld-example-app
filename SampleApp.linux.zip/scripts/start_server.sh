#!/bin/bash 
##service apache reload
service apache2 status